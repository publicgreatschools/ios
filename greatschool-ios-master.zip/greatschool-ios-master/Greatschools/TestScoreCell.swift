//
//  TestScoreCell.swift
//  Greatschools
//
//  Created by SunyQin on 3/10/16.
//  Copyright © 2016 ilabs. All rights reserved.
//

import UIKit

class TestScoreCell: UITableViewCell {
	@IBOutlet weak var titleLabel: UILabel!
	@IBOutlet weak var gradeLabel: UILabel!
	@IBOutlet weak var firstPercentView: PercentView!
	@IBOutlet weak var secondPercentView: PercentView!
	@IBOutlet weak var thirdPercentView: PercentView!
}
