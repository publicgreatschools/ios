# greatschool-react

## to get start with iOS developing

###### assume you have `react-native >= 0.21` installed. @see [Get Started](https://facebook.github.io/react-native/docs/getting-started.html)

1. `npm install`
2. `rnpm link` (install `rnpm` by `npm install rnpm -g` if you don't have it)
3. in ios directory: `pod install`
4. `react-native run-ios`
5. open your favorite editor like http://nuclide.io
