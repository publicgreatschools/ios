'use strict';

import React from 'react-native';
import GreatSchool from './GreatSchool';
React.AppRegistry.registerComponent('GreatSchool', () => GreatSchool);
