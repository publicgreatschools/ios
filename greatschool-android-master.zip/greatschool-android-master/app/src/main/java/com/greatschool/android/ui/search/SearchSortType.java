package com.greatschool.android.ui.search;

public enum SearchSortType {

    DISTANCE, AZ, RATING
}
